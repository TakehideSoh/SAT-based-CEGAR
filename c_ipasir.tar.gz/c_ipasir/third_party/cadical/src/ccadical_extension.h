// Stub extension header for building patched CaDiCaL sources in IPASIR-only mode.
