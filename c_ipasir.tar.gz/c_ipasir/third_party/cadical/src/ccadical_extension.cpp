// Stub extension source for IPASIR-only builds.
